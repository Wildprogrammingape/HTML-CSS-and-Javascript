// prompt button
function dochange(){
  alert('button clicked with Javascript function');
}

// change color function
function changecolor(){
  var divElement1 = document.getElementById("div1");
  var divElement2 = document.getElementById("div2");
  divElement1.className = "blueback";
  divElement2.className = "orangeback";
}

// change text function
function changeText(){
  var divElement1 = document.getElementById("div1");
  var divElement2 = document.getElementById("div2");
  divElement1.innerHTML = "div one changed";
  divElement2.innerHTML = "div two changed";
}

// do magenta
function domagenta(){
  var canvas = document.getElementById("canvas1");
  canvas.style.backgroundColor="magenta";
  var context = canvas.getContext("2d");
  
  context.fillStyle = "yellow";
  context.fillRect(10,10,60,60);
  context.fillRect(80,10,60,60);
  
  context.fillStyle = "black";
  context.font = "20px Arial";
  context.fillText("Hello",15,45);
  context.fillText("there",85,45);
}

//do blue
function doblue(){
  var canvas = document.getElementById("canvas2");
  canvas.style.backgroundColor="blue";
  
  var context = canvas.getContext("2d");
  
  context.fillStyle = "white";//white rectangle
  context.fillRect(10,10,60,60);
  context.fillRect(80,10,60,60);
  
  context.fillStyle = "black";//black font
  context.font = "20px Arial";
  context.fillText("Hello",15,45);
  context.fillText("again",85,45);
}

//color picker
function docolor(){
  var canvas = document.getElementById("canvas3");  //for canvas
  var colorinput = document.getElementById("clr"); // for color picker
  var color = colorinput.value;
  canvas.style.backgroundColor = color;
}

//slider input
function dosquare(){
  
  var canvas = document.getElementById("canvas3");
  var context = canvas.getContext("2d");
  var sizeinput = document.getElementById("slider");
  var size = sizeinput.value;
  context.clearRect(0,0,canvas.width,canvas.height);//remove the rectangle when the slider goes on or the function goes over 
  context.fillStyle = "yellow";
  context.fillRect(10,10,size,size);
}